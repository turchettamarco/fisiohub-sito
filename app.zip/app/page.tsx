import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { WhyChoose } from "@/components/why-choose"
import { About } from "@/components/about"
import { Services } from "@/components/services"
import { Laser } from "@/components/laser"
import { Process } from "@/components/process"
import { Testimonials } from "@/components/testimonials"
import { Location } from "@/components/location"
import { Contact } from "@/components/contact"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <WhyChoose />
        <About />
        <Services />
        <Laser />
        <Process />
        <Testimonials />
        <Location />
        <Contact />
      </main>
      <Footer />
    </>
  )
}
