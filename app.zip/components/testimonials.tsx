"use client"

import { Star } from "lucide-react"

const testimonials = [
  {
    quote: "Dopo mesi di dolore alla schiena, finalmente ho trovato qualcuno che ha capito il problema. Marco mi ha spiegato tutto con chiarezza e insieme abbiamo costruito un percorso che ha funzionato davvero.",
    author: "Paziente verificato",
    detail: "Trattamento lombalgia"
  },
  {
    quote: "Professionalità e competenza. Non si è limitato a trattare il dolore ma mi ha insegnato esercizi da fare a casa. Ora so come gestire la mia cervicale e prevenire le ricadute.",
    author: "Paziente verificato",
    detail: "Trattamento cervicalgia"
  },
  {
    quote: "Finalmente un fisioterapista che ascolta e dedica il tempo necessario. Dopo l'intervento al ginocchio mi ha seguito passo passo nella riabilitazione. Risultati eccellenti.",
    author: "Paziente verificato",
    detail: "Riabilitazione post-chirurgica"
  }
]

export function Testimonials() {
  return (
    <section className="py-20 bg-card">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <p className="text-sm font-medium text-primary uppercase tracking-wider mb-4">
            Testimonianze
          </p>
          <h2 className="text-3xl sm:text-4xl font-semibold text-foreground leading-tight text-balance">
            Cosa dicono i pazienti
          </h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="bg-background p-6 rounded-lg border border-border"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-primary text-primary" />
                ))}
              </div>
              <blockquote className="text-muted-foreground leading-relaxed mb-4">
                "{testimonial.quote}"
              </blockquote>
              <div className="border-t border-border pt-4">
                <p className="font-medium text-foreground">{testimonial.author}</p>
                <p className="text-sm text-muted-foreground">{testimonial.detail}</p>
              </div>
            </div>
          ))}
        </div>
        
        <p className="text-center text-sm text-muted-foreground mt-8">
          * Testimonianze anonimizzate per tutela della privacy dei pazienti
        </p>
      </div>
    </section>
  )
}
