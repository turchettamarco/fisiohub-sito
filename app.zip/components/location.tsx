import Image from "next/image"
import { MapPin, Car } from "lucide-react"

export function Location() {
  return (
    <section id="studio" className="py-24 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <p className="text-sm font-medium text-primary uppercase tracking-wider mb-4">
            Lo Studio
          </p>
          
          <h2 className="text-3xl sm:text-4xl font-semibold text-foreground leading-tight text-balance">
            Dove trovarmi
          </h2>
        </div>
        
        {/* Studio Photos Gallery */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <div className="relative aspect-[4/3] rounded-lg overflow-hidden">
            <Image
              src="/images/img-7468.jpeg"
              alt="Studio di fisioterapia - vista generale con lettino e area di lavoro"
              fill
              className="object-cover"
            />
          </div>
          <div className="relative aspect-[4/3] rounded-lg overflow-hidden">
            <Image
              src="/images/img-8594.jpeg"
              alt="Lettino professionale per trattamenti di fisioterapia e osteopatia"
              fill
              className="object-cover"
            />
          </div>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <MapPin className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Indirizzo</h3>
                <p className="mt-1 text-muted-foreground">
                  Via Galileo Galilei 5<br />
                  Pontecorvo (FR)<br />
                  <span className="text-primary font-medium">presso Studi Galileo</span>
                </p>
              </div>
            </div>
            
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Car className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Parcheggio</h3>
                <p className="mt-1 text-muted-foreground">
                  Parcheggio facile nelle vicinanze dello studio
                </p>
              </div>
            </div>
          </div>
          
          <div className="relative aspect-video rounded-lg overflow-hidden border border-border">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1500!2d13.669597!3d41.459731!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDHCsDI3JzM1LjAiTiAxM8KwNDAnMTAuNSJF!5e0!3m2!1sit!2sit!4v1600000000000!5m2!1sit!2sit"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Mappa dello studio - Via Galileo Galilei 5, Pontecorvo"
              className="absolute inset-0"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
