import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Phone, MessageCircle, ArrowRight } from "lucide-react"

export function Hero() {
  return (
    <section className="relative min-h-[90vh] flex items-center bg-background pt-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div>
            <p className="text-sm font-medium text-primary uppercase tracking-wider mb-4">
              Fisioterapista e Osteopata a Pontecorvo
            </p>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold text-foreground leading-tight tracking-tight text-balance">
              Il dolore ti sta limitando?
            </h1>
            
            <p className="mt-6 text-lg sm:text-xl text-muted-foreground leading-relaxed">
              Mal di schiena, cervicale, dolore alla spalla o al ginocchio: 
              so quanto possa essere frustrante non riuscire a fare le cose di sempre.
            </p>
            
            <p className="mt-4 text-lg text-foreground font-medium">
              Insieme possiamo trovare la causa del problema e costruire 
              un percorso su misura per farti tornare a stare bene.
            </p>
            
            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <Button asChild size="lg" className="text-base">
                <Link href="/prenota" className="flex items-center gap-2">
                  Prenota una valutazione
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
              
              <Button asChild variant="outline" size="lg" className="text-base bg-transparent">
                <a href="tel:+393209631792" className="flex items-center gap-2">
                  <Phone className="h-5 w-5" />
                  320 963 1792
                </a>
              </Button>
              
              <Button asChild variant="outline" size="lg" className="text-base bg-transparent">
                <a 
                  href="https://wa.me/393209631792" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <MessageCircle className="h-5 w-5" />
                  WhatsApp
                </a>
              </Button>
            </div>
          </div>
          
          <div className="relative hidden lg:block">
            <div className="relative aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl">
              <Image
                src="/images/img-2314.jpeg"
                alt="Marco Turchetta - Fisioterapista e Osteopata"
                fill
                className="object-cover object-top"
                priority
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-card p-6 rounded-xl shadow-lg border border-border max-w-xs">
              <p className="text-sm text-muted-foreground">
                "Ogni persona e ogni dolore sono diversi. Per questo ascolto, valuto e creo un percorso pensato solo per te."
              </p>
              <p className="mt-2 text-sm font-medium text-primary">— Marco</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
