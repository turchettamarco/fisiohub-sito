import Link from "next/link"
import Image from "next/image"
import { MapPin, Phone, Mail } from "lucide-react"

const navLinks = [
  { href: "#chi-sono", label: "Chi Sono" },
  { href: "#servizi", label: "Servizi" },
  { href: "#metodo", label: "Come Lavoro" },
  { href: "#studio", label: "Studio" },
  { href: "#contatti", label: "Contatti" },
  { href: "/prenota", label: "Prenota Online" },
]

export function Footer() {
  return (
    <footer className="bg-foreground text-background py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-12">
          <div>
            <Image
              src="/images/progetto-20senza-20titolo.png"
              alt="Logo Marco Turchetta Fisioterapista"
              width={160}
              height={60}
              className="h-12 w-auto mb-4 brightness-0 invert"
            />
            <p className="text-background/70 text-sm leading-relaxed">
              Fisioterapista e osteopata a Pontecorvo (FR). 
              Approccio clinico personalizzato per il trattamento 
              del dolore e il recupero del movimento.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Navigazione</h3>
            <nav className="flex flex-col gap-2">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="text-sm text-background/70 hover:text-background transition-colors"
                >
                  {link.label}
                </Link>
              ))}
            </nav>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contatti</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-background/70 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-background/70">
                  Via Galileo Galilei 5<br />
                  Pontecorvo (FR)
                </span>
              </div>
              
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-background/70 flex-shrink-0" />
                <a 
                  href="tel:+393209631792" 
                  className="text-sm text-background/70 hover:text-background transition-colors"
                >
                  +39 320 963 1792
                </a>
              </div>
              
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-background/70 flex-shrink-0" />
                <a 
                  href="mailto:turchettamarco@gmail.com" 
                  className="text-sm text-background/70 hover:text-background transition-colors"
                >
                  turchettamarco@gmail.com
                </a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-background/10">
          <p className="text-center text-sm text-background/50">
            © {new Date().getFullYear()} Marco Turchetta - Fisioterapia e Osteopatia. Tutti i diritti riservati.
          </p>
        </div>
      </div>
    </footer>
  )
}
