import { 
  Activity, 
  PersonStanding, 
  Dumbbell, 
  HeartPulse,
  Bone,
  Zap,
  Scissors,
  Magnet
} from "lucide-react"

const services = [
  {
    icon: Activity,
    title: "Osteopatia",
    description: "Approccio osteopatico per una visione globale del corpo e il trattamento delle disfunzioni somatiche, ripristinando l'equilibrio del sistema muscolo-scheletrico."
  },
  {
    icon: PersonStanding,
    title: "Rieducazione Posturale Mézières",
    description: "Metodo Mézières per correggere gli squilibri posturali e le tensioni muscolari che causano dolore e limitazioni funzionali."
  },
  {
    icon: Bone,
    title: "Fibrolisi",
    description: "Tecnica manuale mirata per trattare aderenze e fibrosi dei tessuti molli, migliorando la mobilità e riducendo il dolore."
  },
  {
    icon: Scissors,
    title: "Trattamento Cicatrici",
    description: "Tecniche specifiche per il trattamento delle cicatrici che possono causare restrizioni di movimento e dolore riferito."
  },
  {
    icon: HeartPulse,
    title: "Riabilitazione Ortopedica e Neurologica",
    description: "Percorsi riabilitativi personalizzati post-traumatici, post-chirurgici e per patologie neurologiche."
  },
  {
    icon: Dumbbell,
    title: "Esercizio Terapeutico",
    description: "Programmi di esercizi personalizzati per rinforzare, stabilizzare e prevenire recidive, restituendoti autonomia nel movimento."
  },
  {
    icon: Zap,
    title: "Terapia Strumentale",
    description: "Utilizzo di tecnologie come laser, elettroterapia e ultrasuoni per supportare il processo di guarigione e ridurre il dolore."
  },
  {
    icon: Magnet,
    title: "Noleggio Magnetoterapia",
    description: "Servizio di noleggio apparecchi per magnetoterapia domiciliare, per continuare il trattamento comodamente a casa."
  }
]

export function Services() {
  return (
    <section id="servizi" className="py-24 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-sm font-medium text-primary uppercase tracking-wider mb-4">
            Servizi
          </p>
          
          <h2 className="text-3xl sm:text-4xl font-semibold text-foreground leading-tight text-balance">
            Come posso aiutarti
          </h2>
          
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Un approccio clinico basato su evidenze scientifiche, per affrontare 
            il tuo problema in modo efficace e personalizzato.
          </p>
        </div>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service) => (
            <div 
              key={service.title}
              className="group p-6 bg-card rounded-lg border border-border hover:border-primary/30 hover:shadow-sm transition-all"
            >
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <service.icon className="h-6 w-6 text-primary" />
              </div>
              
              <h3 className="font-semibold text-foreground mb-2">
                {service.title}
              </h3>
              
              <p className="text-sm text-muted-foreground leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
