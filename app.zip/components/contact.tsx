import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Phone, Mail, MessageCircle, CalendarDays } from "lucide-react"

export function Contact() {
  return (
    <section id="contatti" className="py-24 bg-card">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center">
          <p className="text-sm font-medium text-primary uppercase tracking-wider mb-4">
            Contatti
          </p>
          
          <h2 className="text-3xl sm:text-4xl font-semibold text-foreground leading-tight text-balance">
            Prenota una valutazione
          </h2>
          
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Contattami per prenotare una valutazione o per qualsiasi informazione. 
            Sarò felice di rispondere alle tue domande.
          </p>
          
          <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="text-base">
              <Link href="/prenota" className="flex items-center gap-2">
                <CalendarDays className="h-5 w-5" />
                Prenota Online
              </Link>
            </Button>
            
            <Button asChild variant="outline" size="lg" className="text-base bg-transparent">
              <a href="tel:+393209631792" className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                +39 320 963 1792
              </a>
            </Button>
            
            <Button asChild variant="outline" size="lg" className="text-base bg-transparent">
              <a 
                href="https://wa.me/393209631792" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-2"
              >
                <MessageCircle className="h-5 w-5" />
                WhatsApp
              </a>
            </Button>
          </div>
          
          <div className="mt-8">
            <a 
              href="mailto:turchettamarco@gmail.com"
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <Mail className="h-5 w-5" />
              turchettamarco@gmail.com
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
