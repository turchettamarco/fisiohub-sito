import Image from "next/image"
import { Check, Zap, Shield, Target } from "lucide-react"

const benefits = [
  "Riduzione del dolore e dell'infiammazione",
  "Accelerazione dei processi di guarigione",
  "Trattamento di contratture e tensioni muscolari",
  "Rigenerazione tissutale profonda",
  "Terapia non invasiva e indolore",
  "Risultati rapidi e duraturi"
]

const applications = [
  {
    icon: Target,
    title: "Patologie muscolo-scheletriche",
    description: "Tendiniti, borsiti, fasciti, epicondiliti, sindrome del tunnel carpale"
  },
  {
    icon: Zap,
    title: "Dolore e infiammazione",
    description: "Cervicalgia, lombalgia, sciatalgia, dolori articolari"
  },
  {
    icon: Shield,
    title: "Rigenerazione tissutale",
    description: "Cicatrici, edemi, lesioni muscolari, recupero post-operatorio"
  }
]

export function Laser() {
  return (
    <section id="laser" className="py-24 bg-card">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <p className="text-sm font-medium text-primary uppercase tracking-wider mb-4">
            Tecnologia Avanzata
          </p>
          
          <h2 className="text-3xl sm:text-4xl font-semibold text-foreground leading-tight text-balance">
            Laserterapia con Zaira
          </h2>
          
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            Nel mio studio utilizzo il laser Zaira di Garda Laser, un dispositivo 
            medicale Made in Italy di ultima generazione per trattamenti efficaci e non invasivi.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="relative">
            <div className="relative aspect-square max-w-md mx-auto">
              <Image
                src="/images/zaira-laser.jpg"
                alt="Laser Zaira - Dispositivo medicale per laserterapia"
                fill
                className="object-contain"
              />
            </div>
          </div>
          
          <div>
            <h3 className="text-2xl font-semibold text-foreground mb-4">
              Cos&apos;è la laserterapia?
            </h3>
            
            <p className="text-muted-foreground leading-relaxed mb-6">
              La laserterapia è una terapia fisica strumentale che utilizza l&apos;energia luminosa 
              per stimolare i processi biologici di riparazione dei tessuti. Il laser Zaira, 
              grazie alle sue multiple lunghezze d&apos;onda, permette di trattare in profondità 
              diverse patologie con precisione e senza dolore.
            </p>
            
            <h4 className="font-semibold text-foreground mb-3">Benefici del trattamento:</h4>
            
            <ul className="space-y-2 mb-8">
              {benefits.map((benefit, index) => (
                <li key={index} className="flex items-start gap-3">
                  <div className="flex-shrink-0 mt-1">
                    <Check className="h-4 w-4 text-primary" />
                  </div>
                  <span className="text-muted-foreground">{benefit}</span>
                </li>
              ))}
            </ul>
            
            <h4 className="font-semibold text-foreground mb-4">Indicazioni terapeutiche:</h4>
            
            <div className="space-y-4">
              {applications.map((app, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <app.icon className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                  <div>
                    <h5 className="font-medium text-foreground">{app.title}</h5>
                    <p className="text-sm text-muted-foreground">{app.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
