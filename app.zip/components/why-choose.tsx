"use client"

import { CheckCircle, Clock, Target, TrendingUp, Heart } from "lucide-react"

const reasons = [
  {
    icon: Target,
    title: "Valutazione clinica approfondita",
    description: "Non mi limito a trattare il sintomo: cerco la causa del tuo dolore attraverso un'analisi accurata."
  },
  {
    icon: CheckCircle,
    title: "Trattamenti personalizzati",
    description: "Ogni percorso è costruito su misura per te, non esistono protocolli standard."
  },
  {
    icon: TrendingUp,
    title: "Approccio progressivo e misurabile",
    description: "Monitoro i tuoi progressi e adatto il trattamento per raggiungere i tuoi obiettivi."
  },
  {
    icon: Clock,
    title: "Tempo dedicato a te",
    description: "Sedute senza fretta, con l'attenzione che meriti. Mai trattamenti frettolosi."
  },
  {
    icon: Heart,
    title: "Terapia manuale ed esercizio",
    description: "Unisco il trattamento manuale all'esercizio terapeutico per risultati duraturi."
  }
]

export function WhyChoose() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-semibold text-foreground leading-tight text-balance">
            Perché scegliere questo studio?
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            Un approccio clinico serio, personalizzato e centrato su di te.
          </p>
        </div>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {reasons.map((reason, index) => (
            <div 
              key={index}
              className="bg-card p-6 rounded-lg border border-border hover:shadow-md transition-shadow"
            >
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <reason.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">{reason.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {reason.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
