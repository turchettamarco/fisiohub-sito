import Image from "next/image"
import { GraduationCap, Award } from "lucide-react"

export function About() {
  return (
    <section id="chi-sono" className="py-24 bg-card">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-5 gap-12 lg:gap-16 items-start">
          {/* Foto e formazione a sinistra */}
          <div className="lg:col-span-2">
            <div className="relative">
              <Image
                src="/images/img-2314.jpeg"
                alt="Marco Turchetta - Fisioterapista e Osteopata"
                width={400}
                height={500}
                className="rounded-2xl shadow-xl object-cover w-full"
              />
            </div>
            
            {/* Formazione sotto la foto */}
            <div className="mt-8 space-y-4">
              <h3 className="text-sm font-medium text-primary uppercase tracking-wider">
                Formazione
              </h3>
              
              <div className="flex items-start gap-3 p-4 bg-background rounded-lg border border-border">
                <GraduationCap className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-foreground text-sm">Laurea in Fisioterapia</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    IRCCS Neuromed di Pozzilli - Sapienza Università di Roma
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-4 bg-background rounded-lg border border-border">
                <Award className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium text-foreground text-sm">Master in Osteopatia</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Disfunzioni Neuro-Muscolo-Scheletriche - EOM, Università di Verona
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Bio a destra */}
          <div className="lg:col-span-3">
            <p className="text-sm font-medium text-primary uppercase tracking-wider mb-4">
              Chi Sono
            </p>
            
            <h2 className="text-3xl sm:text-4xl font-semibold text-foreground leading-tight">
              Ciao, sono Marco
            </h2>
            
            <div className="mt-8 space-y-6 text-muted-foreground leading-relaxed">
              <p>
                Sono un fisioterapista e osteopata, e da anni il mio lavoro e la mia passione 
                coincidono: aiutare le persone a ritrovare il benessere.
              </p>
              
              <p>
                So cosa significa convivere con il dolore, vedere le proprie giornate limitate 
                da un fastidio che non passa. Per questo ho scelto un approccio che unisce 
                <span className="text-foreground font-medium"> competenza scientifica </span> 
                e <span className="text-foreground font-medium">ascolto umano</span>.
              </p>
              
              <p>
                Non credo nelle soluzioni standard. Ogni persona che entra nel mio studio 
                ha una storia diversa, un corpo diverso, esigenze diverse. Il mio compito 
                è capire insieme a te da dove viene il problema e costruire un percorso 
                che funzioni davvero.
              </p>
              
              <p>
                La fisioterapia e l&apos;osteopatia non sono solo trattamenti: sono strumenti 
                per <span className="text-foreground font-medium">migliorare la qualità della vita</span>, 
                ridurre il dolore e recuperare la libertà di movimento.
              </p>
            </div>
            
            <div className="mt-10 p-6 bg-primary/5 rounded-xl border-l-4 border-primary">
              <p className="text-foreground italic">
                &quot;Il mio obiettivo non è solo toglierti il dolore, ma darti gli strumenti 
                per stare bene nel tempo.&quot;
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
