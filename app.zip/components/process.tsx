import { ClipboardList, Target, BookOpen, Repeat, TrendingUp } from "lucide-react"

const steps = [
  {
    number: "01",
    icon: ClipboardList,
    title: "Valutazione",
    description: "Ascolto la tua storia clinica e analizzo il problema attraverso test specifici per individuare la causa del dolore."
  },
  {
    number: "02",
    icon: Target,
    title: "Trattamento Mirato",
    description: "Applico le tecniche più appropriate (terapia manuale, osteopatia, strumentale) in base alla valutazione effettuata."
  },
  {
    number: "03",
    icon: BookOpen,
    title: "Educazione al Movimento",
    description: "Ti spiego cosa sta succedendo al tuo corpo e come puoi contribuire attivamente al miglioramento."
  },
  {
    number: "04",
    icon: Repeat,
    title: "Esercizi Personalizzati",
    description: "Ti insegno esercizi specifici da fare a casa per consolidare i risultati e prevenire recidive."
  },
  {
    number: "05",
    icon: TrendingUp,
    title: "Monitoraggio",
    description: "Verifico i progressi e adatto il percorso terapeutico in base alla tua risposta al trattamento."
  }
]

export function Process() {
  return (
    <section id="metodo" className="py-24 bg-card">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="text-sm font-medium text-primary uppercase tracking-wider mb-4">
            Come Lavoro
          </p>
          
          <h2 className="text-3xl sm:text-4xl font-semibold text-foreground leading-tight text-balance">
            Il mio metodo di lavoro
          </h2>
          
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Un percorso strutturato e trasparente, dove sei sempre informato 
            su cosa stiamo facendo e perché.
          </p>
        </div>
        
        <div className="grid md:grid-cols-5 gap-8">
          {steps.map((step, index) => (
            <div key={step.number} className="relative">
              {/* Connector line for desktop */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-8 left-1/2 w-full h-px bg-border" />
              )}
              
              <div className="relative flex flex-col items-center text-center">
                <div className="relative z-10 w-16 h-16 rounded-full bg-primary flex items-center justify-center mb-4">
                  <step.icon className="h-7 w-7 text-primary-foreground" />
                </div>
                
                <span className="text-xs font-semibold text-primary mb-2">
                  {step.number}
                </span>
                
                <h3 className="font-semibold text-foreground mb-2">
                  {step.title}
                </h3>
                
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
